
            <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            
             <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <!DOCTYPE html>
<html lang="en">

<head>
    
<base href="/public">
    <?php echo $__env->make("admin.admincss", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make("admin.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div>
            <h1 style="font-size: -webkit-xxx-large;">Chef List</h1>
        </div>
        <div style="align:center;margin:auto;">
            <form action="<?php echo e(url('/addchef')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" class="form-control" id="name" placeholder="Enter Name">
                </div>
                <div class="form-group">
                    <label for="speciality">Speciality</label>
                    <input type="textbox" name="speciality" class="form-control" id="speciality" placeholder="Enter Speciality">
                </div>
                <div class="form-group">
                    <label for="price">Image</label>
                    <input type="file" name="image" class="form-control" id="image">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
        <div style="align:center;margin:auto;">
            <table class="table table-striped table-hover">
                <thead>
                    <tr style="background: aliceblue">
                        <th>Action</th>
                        <th>Name</th>
                        <th>Speciality</th>
                    </tr>
                </thead>
             
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chef): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo e(url('/deletechef',$chef['id'])); ?>"> <i class="mdi mdi-delete"></i> </a><!-- <i class="fa fa-trash-can"> -->
                        <a href="<?php echo e(url('/editchef',$chef['id'])); ?>"> <i class="mdi mdi-pencil-box-outline"></i> </a><!-- <i class="fa-solid fa-pen-to-square"></i> -->
                    </td>
                    <td><?php echo e($chef['name']); ?></td>
                    <td><?php echo e($chef['speciality']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
    <?php echo $__env->make("admin.adminscript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH D:\laravel\restro\resources\views/admin/viewchef.blade.php ENDPATH**/ ?>