<!DOCTYPE html>
<html lang="en">

<head>
        <base href="/public">
    <?php echo $__env->make("admin.admincss", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make("admin.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div style="align:center;margin:auto;">
            <form action="<?php echo e(url('/updatefood',$data['id'])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($data['id']); ?>">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" name="title" value="<?php echo e($data['title']); ?>" class="form-control" id="title" placeholder="Enter Food Title">
                </div>
                <div class="form-group">
                    <label for="price">Price</label>
                    <input type="num" name="price" value="<?php echo e($data['price']); ?>" class="form-control" id="price" placeholder="Enter Price">
                </div>
                <div class="form-group">
                    <label for="price">Description</label>
                    <input type="textbox" name="description" value="<?php echo e($data['description']); ?>" class="form-control" id="description" placeholder="Enter Description">
                </div>
                <div class="form-group">
                    <label for="price">Image</label>
                    <input type="file" name="image" value="<?php echo e($data['image']); ?>" class="form-control" id="image">
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    
    </div>
    <?php echo $__env->make("admin.adminscript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH D:\laravel\restro\resources\views/admin/foodupdate.blade.php ENDPATH**/ ?>