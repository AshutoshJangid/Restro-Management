<!DOCTYPE html>
<html lang="en">

<head>
        <base href="/public">
    <?php echo $__env->make("admin.admincss", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make("admin.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div style="align:center;margin:auto;">
            <form action="<?php echo e(url('/updatechef',$data->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" value="<?php echo e($data->name); ?>" class="form-control" id="name" placeholder="Enter Name">
                </div>
                <div class="form-group">
                    <label for="speciality">Speciality</label>
                    <input type="textbox" name="speciality" value="<?php echo e($data->speciality); ?>" class="form-control" id="speciality" placeholder="Enter Speciality">
                </div>
                <div class="form-group">
                    <label for="price">Image</label>
                    <input type="file" name="image" class="form-control" id="image" required>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    
    </div>
    <?php echo $__env->make("admin.adminscript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH D:\laravel\restro\resources\views/admin/chefupdate.blade.php ENDPATH**/ ?>