<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            
             <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
           <!DOCTYPE html>
<html lang="en">

<head>
    
<base href="/public">
    <?php echo $__env->make("admin.admincss", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make("admin.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div>
            <h1 style="font-size: -webkit-xxx-large;">Food Menu</h1>
        </div>
        <div style="align:center;margin:auto;">
            <form action="<?php echo e(url('/uploadfood')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" name="title" class="form-control" id="title" placeholder="Enter Food Title">
                </div>
                <div class="form-group">
                    <label for="price">Price</label>
                    <input type="num" name="price" class="form-control" id="price" placeholder="Enter Price">
                </div>
                <div class="form-group">
                    <label for="price">Description</label>
                    <input type="textbox" name="description" class="form-control" id="description" placeholder="Enter Description">
                </div>
                <div class="form-group">
                    <label for="price">Image</label>
                    <input type="file" name="image" class="form-control" id="image">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
        <div style="align:center;margin:auto;">
            <table class="table table-striped table-hover">
                <thead style="background: aliceblue">
                    <tr>
                        <th>ID</th>
                        <th>ACTION</th>
                        <th>NAME</th>
                        <th>PRICE</th>
                    </tr>
                </thead>
             
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($foods['id']); ?></td>
                    <td>
                        <a href="<?php echo e(url('/deletefood',$foods['id'])); ?>"> <i class="mdi mdi-delete"></i> </a>
                        <a href="<?php echo e(url('/editfood',$foods['id'])); ?>"> <i class="mdi mdi-pencil-box-outline"></i> </a>
                    </td>
                    <td><?php echo e($foods['title']); ?></td>
                    <td><?php echo e($foods['price']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
    <?php echo $__env->make("admin.adminscript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH D:\laravel\restro\resources\views/admin/foodmenu.blade.php ENDPATH**/ ?>