<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make("admin.admincss", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make("admin.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div>
            <h1 style="font-size: -webkit-xxx-large;">Orders</h1>
        </div>
        <div style="align:center;margin:auto;">
            <table class="table table-striped table-hover">
                <thead>
                    <tr style="background: aliceblue">
                        <th>Action</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Order Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total</th>
                    </tr>
                </thead> <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <?php
                    $price = ($orders->price)*($orders->quantity)
                    ?>
                    <tr>
                        <td><a href="<?php echo e(url('/complete',$orders->cid)); ?>">Complete</a></td>
                        <td><?php echo e($orders->name); ?></td>
                        <td><?php echo e($orders->phone); ?></td>
                        <td><?php echo e($orders->title); ?></td>
                        <td><?php echo e($orders->quantity); ?></td>
                        <td>$<?php echo e($orders->price); ?></td>
                        <td>$<?php echo e($price); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php echo $__env->make("admin.adminscript", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH D:\laravel\restro\resources\views//admin/showorders.blade.php ENDPATH**/ ?>